// 🧔 👨 🧔‍♂️ 🧔‍♀️ 🛏️ 🛋️ 🪑 🌳 🫔 🌱 🌾 🌺 🍅 🌽 🏙️
// Declarador de variaveis
let xcam = 0;
let ycam = 0;
let zoomcam = 1.5;
let postgame = 0;
let sfx1;
let sfx2;
let sfx3;
let sfx4;
let sfx5;
let sfx6;
let sng1;
let sng2;
let sng3;
let sng4;
let sng5;
let sng6;
let sng7;
let sng8;
let sng_menu;
let sng_cidade;
let fadeout = 255;
let miho;
let trem;
let fazendeiro;
let fazendeiro2;
let cobra;
let robo1;
let robo2;
let robo3;
let robo4;
let robo5;
let robo6;
let m_encontro;
let gameover = 0;
function preload() {
  // ------------------------------------ sons
  sng1 = loadSound("sng_bat_1.mp3");
  sng2 = loadSound("sng_bat_2.mp3");
  sng3 = loadSound("sng_bat_3.wav");
  sng4 = loadSound("sng_bat_4.mp3");
  sng5 = loadSound("sng_bat_5.mp3");
  sng6 = loadSound("sng_bat_6.mp3");
  sng7 = loadSound("sng_bat_7.mp3");
  sng8 = loadSound("sng_bat_8.mp3");
  sng_menu = loadSound("sng_menu.mp3");
  sng_cidade = loadSound("sng_cidade.mp3");
  // --------------------------------------------
  sfx1 = loadSound("sfx_encontro.mp3");
  sfx2 = loadSound("errou.mp3");
  sfx3 = loadSound("sfx_soco.mp3");
  sfx4 = loadSound("sfx_soco2.mp3");
  sfx5 = loadSound("sfx_lev_up.mp3");
  // ------------------------------------ sprites
  miho = loadImage("Milho agrotoxico.png");
  trem = loadImage("Trem.png");
  fazendeiro = loadImage("Fazendeiro.png");
  fazendeiro2 = loadImage("Fazendeiro 2.png");
  cobra = loadImage("Cobra.png");
  robo1 = loadImage("Robô pequeno.png");
  robo2 = loadImage("Robô de ferro.png");
  robo3 = loadImage("Robô dourado.png");
  robo4 = loadImage("Robô de guerra.png");
  robo5 = loadImage("Robô gigante.png");
  robo6 = loadImage("Robô gigante - Mark 30.png");
}
let cenario_salvo = 1;
let dano = 0;
let x1 = 300;
let y1 = 275;
let y_cobaia = 0;
let x_cobaia = 0;
let ver_lev_up = 0;
let errou = 0;
// --------------------------------------------- //
let debug = 0;
let cenario = 1;
let savestate = 3;
let valor_trans = 500;
// --------------------- //
let ini_bat = 0;
let t_fantasia = 0;
let fantasia = "";
let fantasia_salva = 0;
let player = [25, 25, 1, 0, 5, 5, 5, 5];
// --------------[ HP,m.HP,level, exp, m_exp, dano, def, vel ]
let vel = 2;
let passos = 0;
let m_passos = 150;
let bat = 0;
let dados = [0, 0, 0, 0, 0, 0, 0, 0];
let i = 1;
let i2 = 5;
let hp_ini = 0;
let crit_p = 0;
let crit_i = 0;
let nomesInimigos = [
  "404",
  "Milho vivo",
  "Tomate ambulante",
  "Enxame de mosquitos",
  "Brotos vivos",
  "Tomate agrotóxico",
  "Laranja ambulante",
  "Guardiões da colmeia",
  "Colmeia",
  "---Abelha rainha---",
  "Broto gigante",
  "Milho agrotoxico",
  "TREM VIVO",
  "Fazendeiro - 1",
  "Fazendeiro - 2",
  "Cobra rápida",
  "Robô pequeno",
  "Robô de ferro - MK 01",
  "Robô dourado - MK 07",
  "Robô de batalha - MK 16",
  "Robô de aço - MK 20",
  "Robô de Titânio - MK 30", // 21
];
let hp_inis = [
  9999,
  20,
  15,
  35,
  35,
  37,
  20,
  20,
  50,
  60,
  30,
  40,
  100, // 12
  50,
  70,
  40,
  20,
  50,
  40,
  60, // 19
  100,
  300, // 21
];
let m_hp_inis = [
  9999,
  20,
  15,
  35,
  35,
  37,
  20,
  20,
  50,
  60,
  30,
  40,
  100,
  50,
  70,
  40,
  20,
  50,
  40,
  60, // 19
  100,
  300, // 21
];
let def_inis = [
  9999,
  4,
  3,
  9,
  4,
  6,
  5,
  6,
  9,
  8,
  8,
  11,
  16,
  6,
  7,
  5,
  16,
  19,
  36, // 18
  41,
  41,
  71, // 21
];
let dano_inis = [
  9999,
  2,
  3,
  1,
  3,
  7,
  3,
  3,
  1,
  12,
  2,
  9,
  15,
  5,
  10,
  5,
  10,
  20,
  10, // 18
  20,
  19,
  75,
];
let exp_inis = [
  9999,
  12,
  10,
  17,
  22,
  70,
  17,
  15,
  20,
  60,
  20,
  150,
  110,
  50,
  200,
  72,
  57,
  62,
  152,
  252, // 19
  702,
  705,
];
let vel_inis = [
  9999,
  2,
  2,
  10,
  3,
  5,
  5,
  5,
  1,
  12,
  4,
  5,
  15,
  10,
  12,
  17,
  10,
  9,
  25, // 18
  32,
  35,
  40,
];
let crit_inis = [
  1,
  14,
  14,
  14,
  12,
  13,
  12,
  12,
  20,
  9,
  13,
  11,
  9,
  11,
  10,
  7,
  6,
  8, // 17
  9,
  7,
  8,
  6,
];
let s_bosses = [
  "?",
  0,
  0,
  2,
  2,
  0,
  0,
  0,
  0,
  4,
  3,
  2,
  5,
  2,
  3,
  3,
  3,
  4,
  5,
  6,
  7,
  8,
];
// 21

function setup() {
  createCanvas(700, 500);
  background(0);
  strokeWeight(4);
  imageMode(CENTER);
  textAlign(CENTER);
  sng_menu.loop();
}

// -------------------------- draw()
function draw() {
  push();
  if (cenario <= 2) {
    scale(1);
    translate(0, 0);
  } else if (cenario > 23) {
    scale(1);
    translate(0, 0);
  } else if (cenario === 6) {
    scale(1);
    translate(0, 0);
  } else if (bat === 1) {
    scale(1);
    translate(0, 0);
  } else {
    xcam = (-x1 + 234) * zoomcam;
    ycam = (-y1 + 167) * zoomcam;
    // -------------------------------- colisoes camera
    if (xcam < -431) {
      xcam = -431;
    }
    if (xcam > -15) {
      xcam = -15;
    }
    if (ycam > -6) {
      ycam = -6;
    }
    if (ycam < -265) {
      ycam = -265;
    }
    translate(xcam, ycam);
    scale(1.5);
  }
  if (debug >= 1) {
    // --------------------------------------------- // debug
    console.log((-x1 + 234) * 1.5);
    if (debug === 2) {
      passos = 0;
    }
    if (debug === 3) {
      player[1] = 9999;
      player[0] = 9999;
      player[5] = 99;
      player[7] = 9999;
    } else if (debug === 4) {
      player[1] = 9999;
      player[0] = 9999;
      player[5] = 99;
      player[7] = 9999;
      dados[1] = 1;
      dados[2] = 1;
      dados[3] = 1;
      dados[4] = 1;
    } else if (debug === 5) {
      player[1] = 9999;
      player[0] = 9999;
      player[5] = 99;
      player[7] = 9999;
      dados[1] = 1;
      dados[2] = 1;
      dados[3] = 1;
      dados[4] = 1;
      passos = 0;
    }
  }

  if (bat === 0) {
    if (cenario > 2) {
      if (cenario === 7) {
        if (int(random(1, 16)) === 1) {
          i = 11;
        } else {
          i = 1;
        }
      } else if (cenario === 8) {
        i = 6;
      } else if (cenario > 9) {
        if (cenario < 13) {
          if (int(random(1, 4)) === 1) {
            i = 13;
          } else if (int(random(1, 3)) === 1) {
            i = 6;
          } else {
            i = 15;
          }
        } else if (cenario > 9) {
          if (cenario < 13) {
            if (int(random(1, 4)) === 1) {
              i = 13;
            } else if (int(random(1, 3)) === 1) {
              i = 6;
            } else {
              i = 15;
            }
          } else {
            // ----------------------------- Zona da cidade
            if (cenario <= 16) {
              if (int(random(1, 4)) === 1) {
                i = 16;
              } else if (int(random(1, 4)) === 1) {
                i = 18;
              } else {
                i = 17;
              }
            } else {
              if (int(random(1, 4)) === 1) {
                i = 20;
              } else {
                i = 19;
              }
            }
          }
        } else if (cenario === 7) {
          i = 1;
        } else {
          if (int(random(1, 4)) === 1) {
            i = 6;
          } else {
            if (int(random(1, 11)) === 1) {
              i = 5;
            } else {
              i = 2;
            }
          }
        }
      } else if (int(random(1, 4)) === 1) {
        i = 6;
      } else {
        if (int(random(1, 11)) === 1) {
          i = 5;
        } else {
          i = 2;
        }
      }
    }
    if (t_fantasia === 1) {
      fantasia = "🧔";
    } else if (t_fantasia === 2) {
      fantasia = "👨";
    } else {
      fantasia = "";
    }
    if (cenario === 1) {
      t_fantasia = 0;
      background(0);
      let fantasia = "";
      textAlign(CENTER);
      fill("white");
      textSize(25);
      text("UnderCidade - Entre a terra e o cimento", 350, 150);
      text("🌱 ----- Jogar[1] ----- 🌱", 350, 250);
      text("🏙️ ---- Opções[2] ---- 🏙️", 350, 300);
    }

    if (cenario === 3) {
      background("black");
      fill("rgb(233,201,136)");
      quad(600, 150, 600, 300, 800, 300, 800, 150);
      fill("rgb(141,78,25)");
      quad(70, 70, 630, 70, 630, 430, 70, 430);
      fill("rgb(225,147,80)");
      quad(100, 100, 600, 100, 600, 400, 100, 400);
      textSize(50);
      text("🪑", 150, 200);
      text("🪑", 140, 280);
      textSize(80);
      text("🛏️", 160, 370);
      textSize(30);
      if (dados[1] === 0) {
        text("🦟", 170, 360);
      }
      if (postgame >= 1) {
        image(robo1, 170, 340, 45, 45);
      }
      if (postgame >= 2) {
        image(robo3, 500, 330, 85, 85);
      }
      textSize(80);
      text("🛋️", 400, 160);
    }

    if (cenario === 4) {
      background("rgb(118,169,82)");
      noStroke();
      fill("rgb(233,201,136)");
      quad(-50, 150, -50, 350, 750, 350, 750, 150);
      stroke(0);
      fill("rgb(225,147,80)");
      rect(-10, 10, 50, 480);
      textSize(80);
      text("🌳", 500, 450);
      text("🌳", 150, 100);
      text("🌳", 100, 450);
      textSize(40);
      text("🌺", 300, 450);
      textSize(50);
      text("🌾", 450, 110);
    }

    if (cenario === 5) {
      background("rgb(118,169,82)");
      noStroke();
      fill("rgb(87,55,31)");
      if (dados[1] === 1) {
        x_cobaia = 400;
        y_cobaia = 250;
        while (x_cobaia < 700) {
          square(x_cobaia, y_cobaia, 120);
          x_cobaia += 70;
          y_cobaia--;
        }
      }
      fill("rgb(233,201,136)");
      quad(-50, 150, -50, 350, 300, 400, 500, 250);
      fill("rgb(226,194,128)");
      quad(300, 400, 500, 250, 400, 600, 200, 650);
      stroke(0);
      fill("rgb(87,55,31)");
      quad(200, 20, 550, 60, 600, 200, 200, 150);
      textSize(30);
      text("🍅", 280, 100);
      text("🍅", 380, 110);
      text("🍅", 480, 120);
      textSize(80);
      text("🌳", 600, 470);
    }

    if (cenario === 2) {
      background(0);
      fill("white");
      textSize(30);
      if (dados[6] === 0) {
        text("Era uma vez... Um fazendeiro que trabalhava nos", 350, 80);
        text("campos, nas zonas de agricultura, e um dia,", 350, 120);
        text("recebeu um contrato das CIDADES, e com isso,", 350, 160);
        text("arreganhou suas mangas e partiu de a pé para seu", 350, 200);
        text("primeiro emprego...", 350, 240);
        fill("rgb(197,15,15)");
        text("Mas parecia que tudo ao seu redor o impedia", 350, 350);
        text("de atingir seus objetivos...", 350, 390);
        fill("white");
        text("[Z]", 670, 480);
      } else if (dados[6] === 1) {
        text("Nessa época(19XX), os fazendeiros de campo", 350, 120);
        text("eram extremamente maltratados e atacados por", 350, 160);
        text("máquinas e drones, onde resultava em falta de", 350, 200);
        text("sustento para as pessoas vivendo no campo...", 350, 240);
        fill("rgb(197,15,15)");
        text("E em um dia...", 350, 350);
        text("tudo isso mudou...", 350, 390);
        fill("white");
        text("[Z]", 670, 480);
      } else if (dados[6] === 2) {
        fill("rgb(92,92,92)");
        text("Use as setas para se mover;", 350, 120);
        text("Use [Z] para interagir;", 350, 160);
        text("Use [X] para correr;", 350, 200);
        fill("white");
        text("[Z]", 670, 480);
      }
    }

    if (cenario === 6) {
      background(0);
      textSize(30);
      if (gameover === 1) {
        fill("red");
        text("Game Over!", 350, 100);
      }
      fill("white");
      if (ver_lev_up === 1) {
        text("Você subiu de level!!!", 350, 160);
      }
      text("Level:" + player[2], 350, 200);
      text("Hp:" + player[0] + " / " + player[1], 350, 250);
      text("Defesa:" + player[6], 350, 285);
      text("Dano:" + player[5], 350, 320);
      text("Velocidade:" + player[7], 350, 355);
      text("Exp:" + player[3] + " / " + player[4], 350, 390);
      text("[Z]", 670, 480);
      t_fantasia = 0;
      passos = 0;
    }

    if (cenario === 7) {
      background("rgb(118,169,82)");
      noStroke();
      fill("rgb(226,194,128)");
      quad(250, 0, 500, 0, 500, 600, 250, 650);
      stroke(0);
      fill("rgb(87,55,31)");
      quad(30, 30, 170, 40, 170, 430, 30, 440);
      quad(530, 30, 690, 40, 690, 430, 530, 440);
      y_cobaia = 100;
      while (y_cobaia < 450) {
        textSize(40);
        text("🌽", 100, y_cobaia);
        y_cobaia += 50;
      }
      y_cobaia = 100;
      while (y_cobaia < 450) {
        textSize(40);
        text("🌽", 600, y_cobaia);
        y_cobaia += 50;
      }
    }

    if (cenario === 8) {
      noStroke();
      background("rgb(118,169,82)");
      fill("rgb(226,194,128)");
      quad(250, 0, 500, 0, 500, 600, 250, 650);
      fill("rgb(87,55,31)");
      stroke(0);
      quad(70, 70, 630, 70, 630, 430, 70, 430);
      passos = 0;
      if (dados[1] === 0) {
        y_cobaia = 130;
        while (y_cobaia < 420) {
          textSize(40);
          x_cobaia = 120;
          while (x_cobaia < 600) {
            text("🌱", x_cobaia, y_cobaia);
            x_cobaia += 50;
          }
          y_cobaia += 64;
        }
      }
    }
    if (cenario === 9) {
      noStroke();
      background("rgb(118,169,82)");
      fill("rgb(233,201,136)");
      quad(-50, 150, -50, 350, 550, 350, 560, 150);
      stroke(0);
      textSize(80);
      text("🌳", 500, 450);
      text("🌳", 450, 100);
      if (dados[1] === 1) {
        if (dados[2] === 0) {
          text("🦟", 420, 270);
          passos = 0;
        }
      }
    }
    if (cenario === 10) {
      background("rgb(118,169,82)");
      noStroke();
      fill("rgb(226,194,128)");
      quad(350, 170, 350, 330, 750, 330, 750, 170);
      quad(150, 0, 400, 0, 600, 600, 350, 650);
      fill("rgb(87,55,31)");
      stroke(0);
      quad(20, 40, 140, 60, 220, 450, 80, 440);
      textSize(30);
      text("🍊", 90, 120);
      text("🍊", 105, 200);
      text("🍊", 120, 280);
      text("🍊", 135, 365);
      textSize(60);
      text("🪻", 560, 90);
    }
    if (cenario === 11) {
      noStroke();
      background("rgb(64,103,36)");
      fill("rgb(179,159,119)");
      quad(150, 0, 400, 0, 450, 330, 200, 400);
      textSize(30);
      text("🌿", 500, 150);
      text("🌿", 520, 350);
      text("🌿", 70, 370);
      stroke(0);
      if (dados[3] === 0) {
        image(fazendeiro2, 330, 270, 130, 130);
        passos = 0;
      }
    }
    if (cenario === 12) {
      background("rgb(118,169,82)");
      noStroke();
      fill("rgb(233,201,136)");
      quad(350, 100, 350, 300, 750, 350, 750, 150);
      quad(-50, 150, -50, 350, 350, 300, 350, 100);
      stroke(0);
      textSize(50);
      text("🌻", 500, 450);
      text("🌻", 150, 100);
      text("🌻", 100, 450);
      text("🌻", 350, 400);
      text("🌻", 550, 90);
      text("🌻", 350, 50);
    }
    if (cenario === 13) {
      background("rgb(118,169,82)");
      noStroke();
      fill("rgb(233,201,136)");
      quad(350, 50, 350, 250, 750, 350, 750, 150);
      quad(-50, 100, -50, 350, 350, 250, 350, 50);
      stroke(0);
      if (dados[4] === 0) {
        passos = 0;
        fill("rgb(65,65,141)");
        y_cobaia = -50;
        while (y_cobaia < 600) {
          square(300, y_cobaia, 100, 10);
          y_cobaia += 85;
        }
      }
    }
    if (cenario > 13) {
      if (cenario < 24) {
        background("rgb(129,129,129)");
        fill("rgb(78,78,78)");
        strokeWeight(10);
        quad(350, 130, 350, 400, 750, 350, 750, 150);
        quad(-50, 150, -50, 350, 350, 400, 350, 130);
        noStroke();
        quad(350, 130, 350, 400, 750, 350, 750, 150);
        quad(-50, 150, -50, 350, 350, 400, 350, 130);
        stroke(0);
        strokeWeight(4);
        fill("red");
        textAlign(CENTER);
        textSize(30);
        strokeWeight(2);
        text(cenario - 13, 350, 75);
        strokeWeight(4);
      }
    }
    if (cenario === 24) {
      background(0);
      t_fantasia = 0;
      passos = 0;
      x1 = 350;
      y1 = 250;
      interacao20();
    }
    if (cenario === 25) {
      background(0);
      t_fantasia = 0;
      passos = 0;
      x1 = 350;
      y1 = 250;
      textAlign(CENTER);
      fill("white");
      textSize(30);
      text("Você conseguiu! Diante de todas as", 350, 80);
      text("dificuldades e obstáculos!!!", 350, 120);
      textSize(70);
      fill("yellow");
      if (postgame === 1) {
      text("Contratado!!!", 350, 250);
      } else {
      text("Promovido!!!", 350, 250);
      }
      textSize(30);
      text("🧔 🤜💥🤛 🤖", 350, 350);
      fill("white");
      textAlign(RIGHT);
      text("[Z] --- jogar de novo", 690, 480);
    }
  } else {
    Batalha();
    fantasia = "";
  }

  //presets
  textAlign(CENTER);
  textSize(40);
  text(fantasia, x1, y1);
  if (cenario >= 3) {
    if (cenario === 6) {
    } else {
      if (bat === 0) {
        if (keyIsDown(LEFT_ARROW) === true) {
          x1 -= vel;
          passos++;
          if (passos > m_passos) {
            Batalha();
          }
        }
        if (keyIsDown(RIGHT_ARROW) === true) {
          x1 += vel;
          passos++;
          if (passos > m_passos) {
            Batalha();
          }
        }
        if (keyIsDown(UP_ARROW) === true) {
          y1 -= vel;
          passos++;
          if (passos > m_passos) {
            Batalha();
          }
        }
        if (keyIsDown(DOWN_ARROW) === true) {
          y1 += vel;
          passos++;
          if (passos > m_passos) {
            Batalha();
          }
        }
        if (keyIsDown(88) === true) {
          if (debug >= 1) {
            vel = 12;
          } else {
            vel = 4;
          }
        } else {
          vel = 2;
        }
        if (passos > m_passos) {
          Batalha();
        }
      }

      // ---------------------------- colisao X pra frente
      if (x1 >= 690) {
        if (cenario === 5) {
          cenario = 9;
          x1 = 20;
          fadeout = 255;
        } else if (cenario > 11) {
          if (cenario < 24) {
            if (dados[3] === 1) {
              cenario++;
              x1 = 20;
              fadeout = 255;
              if (cenario === 14) {
                sng_cidade.loop();
              }
            } else {
              x1 = 690;
            }
          } else {
            x1 = 690;
          }
        } else if (cenario === 10) {
          cenario = 12;
          x1 = 20;
          fadeout = 255;
        } else if (cenario === 3) {
          cenario++;
          x1 = 20;
          fadeout = 255;
        } else if (cenario === 4) {
          cenario++;
          x1 = 20;
          fadeout = 255;
        } else {
          x1 = 690;
        }
      }
      if (cenario === 3) {
        if (x1 < 117) {
          x1 = 117;
        }
      }
      // -------------------- colisao X pra tras
      if (x1 <= 11) {
        if (cenario > 3) {
          if (cenario < 6) {
            cenario--;
            x1 = 670;
            fadeout = 255;
          } else if (cenario > 12) {
            cenario--;
            x1 = 670;
            fadeout = 255;
            if (cenario === 13) {
              sng_cidade.stop();
            }
          } else if (cenario === 12) {
            cenario = 10;
            x1 = 670;
            fadeout = 255;
          } else if (cenario === 9) {
            cenario = 5;
            x1 = 670;
            fadeout = 255;
          } else {
            x1 = 11;
          }
        } else {
          x1 = 11;
        }
      }
      // ---------------------------- colisao Y pra cima
      if (y1 <= 27) {
        if (cenario === 7) {
          y1 = 500;
          cenario = 5;
          fadeout = 255;
        } else if (cenario === 8) {
          y1 = 500;
          cenario = 7;
          fadeout = 255;
        } else if (cenario === 10) {
          y1 = 500;
          cenario = 8;
          fadeout = 255;
        } else if (cenario === 11) {
          y1 = 500;
          cenario = 10;
          fadeout = 255;
        } else {
          y1 = 30;
        }
      }
      if (cenario === 3) {
        if (y1 <= 133) {
          y1 = 133;
        }
      }

      if (cenario === 3) {
        if (y1 >= 393) {
          y1 = 390;
        }
      }
      if (cenario === 9) {
        if (x1 >= 350) {
          if (dados[2] === 0) {
            if (dados[1] === 1) {
              i = 3;
              // ------------------------------- mosquitos
              Batalha();
            }
          }
        }
      }
      if (cenario === 13) {
        if (x1 >= 250) {
          if (dados[4] === 0) {
            i = 12;
            // ------------------------------- trem
            Batalha();
          }
        }
      }
      if (cenario === 8) {
        if (y1 >= 250) {
          if (dados[1] === 0) {
            i = 4;
            // ------------------------------- brotos
            Batalha();
          }
        }
      }
      if (cenario === 11) {
        if (y1 >= 250) {
          if (dados[3] === 0) {
            i = 14;
            // ------------------------------- fazendeiro 2
            Batalha();
          }
        }
      }
      // --------------------------------- colisao Y pra baixo
      if (y1 >= 507) {
        if (cenario === 5) {
          y1 = 30;
          cenario = 7;
          fadeout = 255;
        } else if (cenario === 7) {
          y1 = 30;
          cenario = 8;
          fadeout = 255;
        } else if (cenario === 8) {
          if (dados[2] === 1) {
            y1 = 30;
            cenario = 10;
            fadeout = 255;
          } else {
            y1 = 507;
          }
        } else if (cenario === 10) {
          y1 = 30;
          cenario = 11;
          fadeout = 255;
        } else {
          y1 = 507;
        }
      }
    }
  }
  fill(0, 0, 0, fadeout);
  fadeout -= 15;
  square(0, 0, 800);
  pop();
}

function keyReleased() {
  if (key === "2") {
    if (bat === 1) {
      // --------------------------------------------- Turno inimigo
      if (vel_inis[i] - player[7] > int(random(-11, 11))) {
        dano = dano_inis[i] - player[6] * 2;
        if (dano < 1) {
          dano = 1;
        }
        if (int(random(1, crit_inis[i])) === 1) {
          crit_i = 1;
          dano *= 2;
        } else {
          crit_i = 0;
        }
        player[0] -= (dano * postgame);
        if (player[0] < 1) {
          game_over();
        }
      }
    }
  } else {
    if (cenario === 1) {
      cenario = 2;
    }
  }

  if (key === "1") {
    if (bat === 1) {
      // ------------------ Turno player
      danoPlayer();
      if (hp_ini < 1) {
        // -------------- Verifica transorm.
        if (i === 4) {
          dados[1] = 1;
          i = 10;
          ini_bat = 0;
        } else if (i === 14) {
          dados[3] = 1;
          acab_batalha();
        } else if (i === 12) {
          dados[4] = 1;
          acab_batalha();
        } else if (i === 3) {
          // ------------------------------- fim dnv
          dados[2] = 1;
          acab_batalha();
        } else {
          player[3] += exp_inis[i];
          if (player[3] >= player[4]) {
            // ---------------------------- Level up
            while (player[3] >= player[4]) {
              sfx5.play();
              ver_lev_up = 1;
              player[3] -= player[4];
              player[4] += 5;
              player[1] += 2 + int(random(0, 4));
              player[2] += 1 + int(random(0, 4));
              player[5] += 1 + int(random(0, 4));
              player[6] += 1 + int(random(0, 4));
              player[7] += 1 + int(random(0, 4));
              player[0] = player[1];
            }
          }

          // ------------- Fim da batalha
          acab_batalha();
        }
      } else {
        // --------------------------------------------- Turno inimigo
        if (vel_inis[i] - player[7] > int(random(-11, 5))) {
          dano = dano_inis[i] - player[6];
          if (dano < 1) {
            dano = 1;
          }
          if (int(random(1, crit_inis[i])) === 1) {
            crit_i = 1;

            dano *= 2;
          } else {
            crit_i = 0;
          }
          player[0] -= dano;
          if (player[0] < 1) {
            game_over();
          }
        }
      }
    } else {
      if (cenario === 1) {
        cenario = 2;
        sng_menu.stop();
      }
    }
  }
  if (key === "3") {
    if (bat === 1) {
      if (s_bosses[i] <= 1) {
        ini_bat = 0;
        bat = 0;
        passos = 0;
      }
    }
  }
  if (key === "z") {
    if (cenario === 6) {
      cenario = cenario_salvo;
      t_fantasia = fantasia_salva;
      ver_lev_up = 0;
      gameover = 0;
    } else if (cenario === 2) {
      if (dados[6] < 2) {
        dados[6]++;
        fadeout = 255;
      } else {
        cenario = 3;
        t_fantasia = 1;
        sng_menu.stop();
      }
    } else if (cenario === 24) {
      if (dados[5] < 1) {
        dados[5]++;
        fadeout = 255;
      } else {
        i = 21;
        Batalha();
      }
    } else if (cenario === 25) {
      cenario = 3;
      t_fantasia = 1;
      dados[5] = 0;
      fadeout = 255;
      x1 = 350;
      y1 = 250;
    }
  }
}

function Batalha() {
  if (cenario > 3) {
    bat = 1;
    dados[0] = fantasia;
    fantasia = "";
    if (i === 1) {
      background("rgb(57,136,0)");
      fill("rgb(6,58,6)");
      triangle(370, 275, 400, 290, 400, 200);
      triangle(350, 275, 320, 290, 290, 200);
      fill("rgb(231,231,58)");
      ellipse(350, 240, 80, 130);
      fill("green");
      triangle(315, 275, 400, 275, 350, 345);
      triangle(350, 275, 320, 290, 260, 205);
      triangle(370, 275, 400, 290, 430, 205);
      fill("black");
      ellipse(340, 225, 7, 30);
      ellipse(365, 225, 7, 30);
      line(335, 250, 370, 250);
    } else if (i === 2) {
      background("rgb(120,216,52)");
      floresta();
      fill("rgb(221,50,50)");
      circle(350, 250, 100);
      fill("rgb(40,197,40)");
      rect(300, 200, 100, 15);
      rect(343, 185, 15, 50);
      circle(320, 250, 30);
      circle(380, 255, 30);
      fill("black");
      circle(320, 250, 15);
      circle(380, 255, 15);
    } else if (i === 3) {
      background("#1B2561");
      y_cobaia = 100;
      while (y_cobaia < 400) {
        x_cobaia = 100;
        while (x_cobaia < 600) {
          text("🦟", x_cobaia + random(-10, 10), y_cobaia + random(-10, 10));
          x_cobaia += 200 - hp_ini * 3;
        }
        y_cobaia += 90 - hp_ini;
      }
    } else if (i === 4) {
      background("rgb(57,136,0)");
      textSize(60);
      y_cobaia = 200;
      while (y_cobaia < 400) {
        x_cobaia = 200;
        while (x_cobaia < 600) {
          text("🌱", x_cobaia, y_cobaia);
          fill("rgb(38,90,18)");
          ellipse(
            x_cobaia - 15 + random(-1, 1),
            y_cobaia - 30 + random(-1, 1),
            10,
            10
          );
          ellipse(
            x_cobaia + 17 + random(-1, 1),
            y_cobaia - 37 + random(-1, 1),
            10,
            10
          );
          x_cobaia += 80;
        }
        y_cobaia += 60;
      }
    } else if (i === 5) {
      background(65);
      line(330, 300, 315, 370);
      line(400, 300, 420, 390);
      fill("rgb(184,49,100)");
      circle(300, 200, 50);
      circle(350, 250, 140);
      ellipse(405, 305, 80, 60);
      fill("rgb(52,139,52)");
      rect(320, 190, 100, 15);
      rect(363, 175, 15, 50);
      triangle(315, 370, 290, 380, 319, 350);
      triangle(420, 390, 450, 400, 415, 370);
      fill("rgb(232,199,84)");
      ellipse(340, 250, 90, 50);
      ellipse(405, 305, 50, 25);
      fill("black");
      ellipse(405, 305, 3, 15);
      ellipse(340, 250, 5, 45);
    } else if (i === 6) {
      background("rgb(120,216,52)");
      floresta();
      fill("orange");
      ellipse(350, 250, 110, 100);
      fill("#893C20");
      triangle(343, 185, 350, 220, 360, 180);
      fill("black");
      circle(320, 245, 25);
      circle(380, 255, 25);
      triangle(335, 270, 355, 270, 345, 285);
    } else if (i === 10) {
      background("rgb(47,104,6)");
      fill("rgb(26,219,26)");
      circle(315, 230, 50);
      circle(280, 265, 50);
      circle(270, 300, 35);
      circle(380, 230, 50);
      circle(415, 265, 50);
      circle(430, 300, 35);
      triangle(350, 170, 320, 350, 370, 340);
      quad(300, 120, 230, 100, 280, 160, 350, 170);
      quad(400, 120, 480, 100, 430, 160, 350, 170);
      fill("red");
      triangle(
        280 + random(-3, 3),
        145 + random(-3, 3),
        320 + random(-3, 3),
        155 + random(-3, 3),
        275 + random(-3, 3),
        125 + random(-3, 3)
      );
      triangle(
        430 + random(-3, 3),
        145 + random(-3, 3),
        385 + random(-3, 3),
        155 + random(-3, 3),
        435 + random(-3, 3),
        125 + random(-3, 3)
      );
      fill("brown");
      triangle(400, 470, 320, 350, 370, 340);
      triangle(280, 470, 320, 350, 370, 340);
    } else if (i === 11) {
      background("#1B2561");
      image(miho, 350, 250, 230, 250);
    } else if (i === 12) {
      background(75);
      image(trem, 350 + int(random(-2, 3)), 250 + int(random(-2, 3)), 350, 350);
    } else if (i === 13) {
      background("rgb(57,136,0)");
      image(fazendeiro, 350, 250, 300, 300);
    } else if (i === 14) {
      background("rgb(57,136,0)");
      image(fazendeiro2, 350, 250, 300, 300);
    } else if (i === 15) {
      background("rgb(57,136,0)");
      image(cobra, 350, 250, 200, 200);
    } else if (i === 16) {
      background(55);
      image(robo1, 350, 250, 200, 200);
    } else if (i === 17) {
      background(55);
      image(robo2, 350, 250, 300, 300);
    } else if (i === 18) {
      background(55);
      image(robo3, 350, 250, 300, 300);
    } else if (i === 19) {
      background(55);
      image(robo4, 350, 250, 300, 300);
    } else if (i === 20) {
      background(40);
      image(robo5, 350, 240, 320, 320);
    } else if (i === 21) {
      background("rgb(97,16,166)");
      image(
        robo6,
        350 + int(random(-1, 2)),
        230 + int(random(-1, 2)),
        370,
        350
      );
    }
    fill("black");
    quad(0, 70, 700, 70, 700, 0, 0, 0);
    fill("white");
    textSize(30);
    if (i === 21) {
      fill("red");
    }
    text("Encontrou " + nomesInimigos[i] + "!!!", 350, 45);
    fill("black");
    quad(0, 430, 0, 500, 700, 500, 700, 430);
    fill("white");
    textSize(25);
    textAlign(CENTER);
    text("[1] lutar   [2] defender   [3]fugir", 450, 485);
    textAlign(LEFT);
    textSize(20);
    fill("black");
    quad(0, 340, 0, 430, 230, 430, 230, 340);
    fill("white");
    text("HP inimigo: " + hp_ini + "/" + m_hp_inis[i], 10, 375);
    text("Seu HP: " + player[0] + "/" + player[1], 10, 400);
    if (crit_p === 1) {
      fill("rgb(255,0,34)");
      text("Você acertou um crítico!", 5, 430);
    }
    if (crit_i === 1) {
      fill("#5C00FF");
      text(nomesInimigos[i] + " acertou um crítico!", 5, 450);
    }
    textAlign(CENTER);
    let escolha = 0;
    if (ini_bat === 0) {
      musica();
      fadeout = 255;
      valor_trans = 30;
      ini_bat = 1;
      hp_ini = hp_inis[i];
      let hp_s_ini = hp_ini;
      m_passos = int(random(160, 400));
    }
    if (valor_trans > 1) {
      if (valor_trans === 2) {
        if (i === 3) {
        }
      }
      if (errou === 0) {
        noStroke();
        fill(0, 0, 0, 210);
        square(350 - valor_trans * 9, 250 - valor_trans * 9, valor_trans * 18);
        stroke(0);
        strokeWeight(4);
      } else {
        fill("black");
        textAlign(LEFT);
        textSize(30);
        strokeWeight(2);
        text("Errou!", 10, 130);
        strokeWeight(4);
      }
      valor_trans--;
    }
  } else {
    passos = 0;
  }
}

function danoPlayer() {
  if (player[7] - vel_inis[i] > int(random(-11, 5))) {
    errou = 0;
    dano = player[5] - def_inis[i];
    if (dano < 1) {
      dano = 1;
    }
    // critico
    if (int(random(1, 5)) === 1) {
      crit_p = 1;
      sfx3.play();

      dano *= 2;
    } else {
      crit_p = 0;
      sfx4.play();
    }

    hp_ini -= dano;
    valor_trans = 10;
  } else {
    sfx2.play();
    errou = 1;
    valor_trans = 100;
  }
}

function musica() {
  parar_mus();
  sfx1.play();
  if (s_bosses[i] <= 1) {
    sng1.loop();
  } else if (s_bosses[i] === 2) {
    sng2.loop();
  } else if (s_bosses[i] === 3) {
    sng3.loop();
  } else if (s_bosses[i] === 4) {
    sng4.loop();
  } else if (s_bosses[i] === 5) {
    sng5.loop();
  } else if (s_bosses[i] === 6) {
    sng6.loop();
  } else if (s_bosses[i] === 7) {
    sng7.loop();
  } else if (s_bosses[i] === 8) {
    sng8.loop();
  } else {
    sng1.loop();
  }
}

function parar_mus() {
  sng1.stop();
  sng2.stop();
  sng3.stop();
  sng4.stop();
  sng5.stop();
  sng6.stop();
  sng7.stop();
  sng8.stop();
  sng_menu.stop();
  sng_cidade.stop();
}

function acab_batalha() {
  parar_mus();
  ini_bat = 0;
  bat = 0;
  passos = 0;
  crit_p = 0;
  crit_i = 0;
  fantasia_salva = t_fantasia;
  cenario_salvo = cenario;
  if (cenario > 13) {
    if (cenario < 24) {
      sng_cidade.loop();
    }
  }
  if (i === 21) {
    fadeout = 255;
    cenario = 25;
    postgame += 1;
  } else {
    cenario = 6;
  }
}

function game_over() {
  if (i === 21) {
    t_fantasia = 2;
    dados = [0, 0, 0, 0, 0, 0, 0, 0];
  }
  parar_mus();
  ini_bat = 0;
  bat = 0;
  passos = 0;
  crit_p = 0;
  crit_i = 0;
  x1 = 350;
  y1 = 250;
  player[0] = player[1];
  fantasia_salva = t_fantasia;
  cenario_salvo = 3;
  cenario = 6;
  gameover = 1;
}

function interacao20() {
  if (dados[5] === 0) {
    fill(255);
    textAlign(CENTER);
    textSize(25);
    text("Mmmmhhh", 350, 225);
    text("Parece que você esteve bem ocupado", 350, 250);
    text("para chegar até aqui...", 350, 275);
    text("[Z]", 670, 480);
  } else if (dados[5] === 1) {
    fill(255);
    textAlign(CENTER);
    textSize(25);
    text("Então vamos ver...", 350, 250);
    fill("red");
    text("Se você é digno de ser contratado!!!", 350, 275);
    fill(255);
    text("[Z]", 670, 480);
  }
}

function floresta() {
  textSize(120);
  noStroke();
  fill("rgb(179,159,119)");
  quad(300, 0, 400, 0, 550, 510, 150, 510);
  stroke(0);
  text("🌳", 600, 150);
  text("🌳", 100, 200);
}
